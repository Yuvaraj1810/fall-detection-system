# Logging alerts and fall events
